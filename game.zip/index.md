---
title: 游戏机
date: 2021-10-16 22:56:06
---
{% raw %}
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
	<title>游戏机</title>
	<style type="text/css">
	@media screen and (orientation: landscape) {		/*横屏*/
		#print {
			position: relative;
			left: -75px;
			margin: 0 auto;
			transform: scale(0.7);
		}
		#switch {
			height: 600px;
			width: 130%
		}

	}

		@media screen and (orientation: portrait) {		/*竖屏*/
			#print {
				position: relative;
				left: -108px;
				bottom: 10px;
				margin: 0 auto;
				transform: scale(0.47);
			}
			#switch {
				height: 400px;
				width: 750px;
			}
		} 

		.not-home-page {
			background-image: url('/img/game.jpg')!important;
		}
		
		body {
			background: url("https://cjunn.gitee.io/blog_theme_atum/img/body/background.jpg") ;
			background-attachment: fixed;
			background-size: cover;
		}		
	</style>

</head>
<body>
<div id="print">
	<iframe id="switch" src="./switch.html" frameborder=no  border=0  marginwidth=0  marginheight=0  scrolling=no></iframe>
</div>
</body>
</html>

{% endraw %}


{% note info modern %}
<p style="font-weight: bold; ">使用说明书：</p>
<p>
	Y键：开始游戏<br>
	B键：单独打开游戏页面<br>
	A键：全屏游戏（手机需要横屏显示，且暂不支持所有分辨率的手机）<br>
	X键：返回上一级<br><br>
	
	另：只有部分游戏可以使用方向键进行控制
</p>
{% endnote %}